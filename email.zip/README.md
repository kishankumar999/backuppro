# BackupPro 
Backup Pro - MySQL Automated backups to Google Drive. 

# Screenshots 

## Taking backup on Google Drive. 
![backuppro](https://github.com/shishirraven/backuppro/assets/4470383/4f29a94f-cabd-406b-932f-1349b9f60752)

## Dashboard 
![localhost_backuppro_dashboard php](https://github.com/shishirraven/backuppro/assets/4470383/8459c940-d903-44f0-b436-6bd019da61d3)

## Login Screen
![image](https://github.com/shishirraven/backuppro/assets/4470383/b6f26cfb-83d7-4f05-a672-5002bce6a909)

## Automation Schedule Setup
![image](https://github.com/shishirraven/backuppro/assets/4470383/a6bfe987-1095-4044-b7c4-0f600001cb32)

## Installation.
![localhost_backuppro_setup php](https://github.com/shishirraven/backuppro/assets/4470383/9bb880c6-4309-4442-a449-268ddf890ae8)


## Development - How to Rebuild the output.css 

We use tailwind CSS in this project. To rebuild it use the following command. 

```
npx tailwindcss -i input.css -o ./css/output.css --watch
```



